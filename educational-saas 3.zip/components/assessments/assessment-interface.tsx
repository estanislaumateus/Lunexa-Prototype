"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CheckCircle, Clock, Trophy, Play } from "lucide-react"

export function AssessmentInterface() {
  const [selectedAssessment, setSelectedAssessment] = useState<string | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [showResults, setShowResults] = useState(false)

  const assessments = [
    {
      id: "1",
      title: "Matemática Básica",
      subject: "Matemática",
      questions: 10,
      duration: "15 min",
      difficulty: "Fácil",
      completed: true,
      score: 8.5,
    },
    {
      id: "2",
      title: "História do Brasil",
      subject: "História",
      questions: 15,
      duration: "20 min",
      difficulty: "Médio",
      completed: false,
      score: null,
    },
    {
      id: "3",
      title: "Física Quântica",
      subject: "Física",
      questions: 20,
      duration: "30 min",
      difficulty: "Difícil",
      completed: true,
      score: 7.2,
    },
  ]

  const sampleQuestions = [
    {
      id: 1,
      question: "Qual é o resultado de 2 + 2?",
      options: ["3", "4", "5", "6"],
      correct: "4",
    },
    {
      id: 2,
      question: "Qual é a capital do Brasil?",
      options: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador"],
      correct: "Brasília",
    },
    {
      id: 3,
      question: "Quem descobriu o Brasil?",
      options: ["Cristóvão Colombo", "Pedro Álvares Cabral", "Vasco da Gama", "Fernão de Magalhães"],
      correct: "Pedro Álvares Cabral",
    },
  ]

  const startAssessment = (assessmentId: string) => {
    setSelectedAssessment(assessmentId)
    setCurrentQuestion(0)
    setAnswers({})
    setShowResults(false)
  }

  const handleAnswerSelect = (questionId: number, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  const nextQuestion = () => {
    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      setShowResults(true)
    }
  }

  const calculateScore = () => {
    let correct = 0
    sampleQuestions.forEach((q, index) => {
      if (answers[q.id] === q.correct) {
        correct++
      }
    })
    return (correct / sampleQuestions.length) * 10
  }

  if (selectedAssessment && !showResults) {
    const question = sampleQuestions[currentQuestion]
    const progress = ((currentQuestion + 1) / sampleQuestions.length) * 100

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Avaliação em Andamento</h3>
            <p className="text-sm text-muted-foreground">
              Questão {currentQuestion + 1} de {sampleQuestions.length}
            </p>
          </div>
          <Badge variant="outline">
            <Clock className="h-4 w-4 mr-1" />
            15:00
          </Badge>
        </div>

        <Progress value={progress} className="h-2" />

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{question.question}</CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup
              value={answers[question.id] || ""}
              onValueChange={(value) => handleAnswerSelect(question.id, value)}
            >
              {question.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>

            <div className="flex justify-between mt-6">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
                disabled={currentQuestion === 0}
              >
                Anterior
              </Button>
              <Button onClick={nextQuestion} disabled={!answers[question.id]}>
                {currentQuestion === sampleQuestions.length - 1 ? "Finalizar" : "Próxima"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (showResults) {
    const score = calculateScore()
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Trophy className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle>Avaliação Concluída!</CardTitle>
            <CardDescription>Confira seu desempenho abaixo</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div>
              <div className="text-4xl font-bold text-green-600">{score.toFixed(1)}</div>
              <div className="text-sm text-muted-foreground">Nota final</div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {Object.values(answers).filter((answer, index) => answer === sampleQuestions[index]?.correct).length}
                </div>
                <div className="text-sm text-muted-foreground">Acertos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {sampleQuestions.length -
                    Object.values(answers).filter((answer, index) => answer === sampleQuestions[index]?.correct).length}
                </div>
                <div className="text-sm text-muted-foreground">Erros</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {Math.round(
                    (Object.values(answers).filter((answer, index) => answer === sampleQuestions[index]?.correct)
                      .length /
                      sampleQuestions.length) *
                      100,
                  )}
                  %
                </div>
                <div className="text-sm text-muted-foreground">Aproveitamento</div>
              </div>
            </div>

            <div className="flex gap-2 justify-center">
              <Button onClick={() => setSelectedAssessment(null)}>Voltar às Avaliações</Button>
              <Button variant="outline">Ver Correção</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avaliações Feitas</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assessments.filter((a) => a.completed).length}</div>
            <p className="text-xs text-muted-foreground">Este mês</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Média Geral</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(
                assessments.filter((a) => a.score).reduce((acc, a) => acc + (a.score || 0), 0) /
                assessments.filter((a) => a.score).length
              ).toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">Últimas avaliações</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assessments.filter((a) => !a.completed).length}</div>
            <p className="text-xs text-muted-foreground">Para fazer</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Melhor Nota</CardTitle>
            <Trophy className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.max(...assessments.filter((a) => a.score).map((a) => a.score || 0)).toFixed(1)}
            </div>
            <p className="text-xs text-muted-foreground">Recorde pessoal</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Avaliações Disponíveis</CardTitle>
          <CardDescription>Teste seus conhecimentos e acompanhe seu progresso</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {assessments.map((assessment) => (
              <Card key={assessment.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{assessment.subject}</Badge>
                    <Badge
                      variant={
                        assessment.difficulty === "Fácil"
                          ? "default"
                          : assessment.difficulty === "Médio"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {assessment.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg">{assessment.title}</CardTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>{assessment.questions} questões</span>
                    <span>{assessment.duration}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    {assessment.completed ? (
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium">Nota: {assessment.score}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">Não realizada</span>
                    )}
                    <Button size="sm" onClick={() => startAssessment(assessment.id)}>
                      <Play className="h-4 w-4 mr-2" />
                      {assessment.completed ? "Refazer" : "Iniciar"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
