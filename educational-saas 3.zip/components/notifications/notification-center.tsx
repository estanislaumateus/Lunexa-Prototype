"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Bell, CheckCircle, AlertTriangle, BookOpen, Calendar } from "lucide-react"

export function NotificationCenter() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: "reminder",
      title: "Lembrete de Estudo",
      message: "Hora de estudar Matemática! Você tem 30 minutos agendados.",
      time: "2 min atrás",
      read: false,
      icon: BookOpen,
      color: "text-blue-600",
    },
    {
      id: 2,
      type: "assessment",
      title: "Avaliação Pendente",
      message: "Você tem uma avaliação de História para completar.",
      time: "1 hora atrás",
      read: false,
      icon: AlertTriangle,
      color: "text-orange-600",
    },
    {
      id: 3,
      type: "achievement",
      title: "Meta Atingida!",
      message: "Parabéns! Você completou sua meta semanal de estudos.",
      time: "3 horas atrás",
      read: true,
      icon: CheckCircle,
      color: "text-green-600",
    },
    {
      id: 4,
      type: "schedule",
      title: "Sessão Agendada",
      message: "Sua próxima sessão de Física está marcada para amanhã às 14h.",
      time: "1 dia atrás",
      read: true,
      icon: Calendar,
      color: "text-purple-600",
    },
  ])

  const [settings, setSettings] = useState({
    studyReminders: true,
    assessmentAlerts: true,
    achievementNotifications: true,
    weeklyReports: true,
    emailNotifications: false,
  })

  const markAsRead = (id: number) => {
    setNotifications((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notif) => ({ ...notif, read: true })))
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Notificações</h3>
          {unreadCount > 0 && <Badge variant="destructive">{unreadCount}</Badge>}
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={markAllAsRead}>
            Marcar todas como lidas
          </Button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Notificações Recentes</CardTitle>
              <CardDescription>Acompanhe lembretes, alertas e atualizações importantes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`flex items-start gap-4 p-4 rounded-lg border ${
                      !notification.read
                        ? "bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800"
                        : "hover:bg-muted"
                    } cursor-pointer transition-colors`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className={`p-2 rounded-full bg-white dark:bg-gray-800 ${notification.color}`}>
                      <notification.icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{notification.title}</h4>
                        <span className="text-xs text-muted-foreground">{notification.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{notification.message}</p>
                      {!notification.read && <div className="w-2 h-2 bg-blue-600 rounded-full"></div>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Configurações</CardTitle>
              <CardDescription>Personalize suas preferências de notificação</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="study-reminders" className="text-sm">
                    Lembretes de Estudo
                  </Label>
                  <Switch
                    id="study-reminders"
                    checked={settings.studyReminders}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, studyReminders: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="assessment-alerts" className="text-sm">
                    Alertas de Avaliação
                  </Label>
                  <Switch
                    id="assessment-alerts"
                    checked={settings.assessmentAlerts}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, assessmentAlerts: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="achievement-notifications" className="text-sm">
                    Conquistas
                  </Label>
                  <Switch
                    id="achievement-notifications"
                    checked={settings.achievementNotifications}
                    onCheckedChange={(checked) =>
                      setSettings((prev) => ({ ...prev, achievementNotifications: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="weekly-reports" className="text-sm">
                    Relatórios Semanais
                  </Label>
                  <Switch
                    id="weekly-reports"
                    checked={settings.weeklyReports}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, weeklyReports: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="email-notifications" className="text-sm">
                    Notificações por Email
                  </Label>
                  <Switch
                    id="email-notifications"
                    checked={settings.emailNotifications}
                    onCheckedChange={(checked) => setSettings((prev) => ({ ...prev, emailNotifications: checked }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-sm">Resumo de Hoje</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span>Sessões de estudo</span>
                <Badge variant="secondary">2</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Avaliações pendentes</span>
                <Badge variant="destructive">1</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Meta diária</span>
                <Badge variant="default">75%</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
