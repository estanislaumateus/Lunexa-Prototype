"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, Plus } from "lucide-react"

export function StudyCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date())

  const studyDays = [
    { date: "2024-01-15", subjects: ["Matemática", "História"], hours: 3.5 },
    { date: "2024-01-14", subjects: ["Física"], hours: 2.0 },
    { date: "2024-01-13", subjects: ["Inglês", "Química"], hours: 2.5 },
    { date: "2024-01-12", subjects: ["Matemática"], hours: 1.5 },
    { date: "2024-01-10", subjects: ["História", "Física"], hours: 4.0 },
  ]

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null)
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day)
    }

    return days
  }

  const getStudyDataForDay = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return studyDays.find((sd) => sd.date === dateStr)
  }

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <p className="text-sm text-muted-foreground">Visualize seus dias de estudo</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigateMonth("next")}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Agendar
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Calendário de Estudos</CardTitle>
          <CardDescription>Dias com atividades de estudo são destacados</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {weekDays.map((day) => (
              <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {getDaysInMonth(currentDate).map((day, index) => {
              if (day === null) {
                return <div key={index} className="p-2"></div>
              }

              const studyData = getStudyDataForDay(day)
              const hasStudy = !!studyData

              return (
                <div
                  key={day}
                  className={`p-2 min-h-[80px] border rounded-lg ${
                    hasStudy ? "bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800" : "hover:bg-muted"
                  } cursor-pointer transition-colors`}
                >
                  <div className="text-sm font-medium mb-1">{day}</div>
                  {studyData && (
                    <div className="space-y-1">
                      <div className="text-xs text-blue-600 font-medium">{studyData.hours}h</div>
                      <div className="flex flex-wrap gap-1">
                        {studyData.subjects.slice(0, 2).map((subject) => (
                          <Badge key={subject} variant="secondary" className="text-xs px-1 py-0">
                            {subject.slice(0, 3)}
                          </Badge>
                        ))}
                        {studyData.subjects.length > 2 && (
                          <Badge variant="secondary" className="text-xs px-1 py-0">
                            +{studyData.subjects.length - 2}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Resumo do Mês</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{studyDays.length}</div>
              <div className="text-sm text-muted-foreground">Dias de Estudo</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {studyDays.reduce((acc, day) => acc + day.hours, 0)}h
              </div>
              <div className="text-sm text-muted-foreground">Total de Horas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {Math.round((studyDays.reduce((acc, day) => acc + day.hours, 0) / studyDays.length) * 10) / 10}h
              </div>
              <div className="text-sm text-muted-foreground">Média por Dia</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
