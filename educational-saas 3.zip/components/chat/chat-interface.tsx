"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Bot, User, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function ChatInterface() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      content: "Olá! Sou seu assistente de estudos. Como posso ajudá-lo hoje?",
      sender: "ai",
      timestamp: new Date(),
      aiProvider: "ChatGPT",
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [currentAI, setCurrentAI] = useState("ChatGPT")

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: messages.length + 1,
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")

    // Simular resposta da IA
    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        content:
          "Esta é uma resposta simulada da IA. Em um sistema real, aqui seria integrada uma API de IA como ChatGPT, Gemini ou Claude.",
        sender: "ai",
        timestamp: new Date(),
        aiProvider: currentAI,
      }
      setMessages((prev) => [...prev, aiResponse])
    }, 1000)
  }

  const switchAI = (newAI: string) => {
    setCurrentAI(newAI)
    const switchMessage = {
      id: messages.length + 1,
      content: `Trocando para ${newAI} devido ao limite de uso atingido.`,
      sender: "system",
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, switchMessage])
  }

  return (
    <div className="space-y-6">
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          IA atual: <strong>{currentAI}</strong>. O sistema troca automaticamente entre IAs quando necessário.
        </AlertDescription>
      </Alert>

      <div className="flex gap-2">
        <Button variant={currentAI === "ChatGPT" ? "default" : "outline"} size="sm" onClick={() => switchAI("ChatGPT")}>
          ChatGPT
        </Button>
        <Button variant={currentAI === "Gemini" ? "default" : "outline"} size="sm" onClick={() => switchAI("Gemini")}>
          Gemini
        </Button>
        <Button variant={currentAI === "Claude" ? "default" : "outline"} size="sm" onClick={() => switchAI("Claude")}>
          Claude
        </Button>
      </div>

      <Card className="h-[500px] flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Chat com IA
          </CardTitle>
          <CardDescription>Tire suas dúvidas e receba explicações personalizadas</CardDescription>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto space-y-4 mb-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.sender !== "user" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{message.sender === "ai" ? <Bot className="h-4 w-4" /> : "S"}</AvatarFallback>
                  </Avatar>
                )}

                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.sender === "user"
                      ? "bg-primary text-primary-foreground"
                      : message.sender === "system"
                        ? "bg-yellow-100 text-yellow-800 border border-yellow-200"
                        : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  {message.aiProvider && (
                    <Badge variant="secondary" className="mt-2 text-xs">
                      {message.aiProvider}
                    </Badge>
                  )}
                </div>

                {message.sender === "user" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Input
              placeholder="Digite sua pergunta..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <Button onClick={handleSendMessage}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
