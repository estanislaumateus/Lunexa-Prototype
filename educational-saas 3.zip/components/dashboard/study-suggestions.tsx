"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Play, Loader2 } from "lucide-react"
import { getAIStudySuggestions } from "@/app/actions/study"
import { useRouter } from "next/navigation"

export function StudySuggestions() {
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    async function loadSuggestions() {
      try {
        const result = await getAIStudySuggestions()
        if (result.suggestions) {
          setSuggestions(result.suggestions)
        }
      } catch (error) {
        console.error("Erro ao carregar sugestões:", error)
      } finally {
        setLoading(false)
      }
    }

    loadSuggestions()
  }, [])

  const getLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case "fundamental":
        return "bg-blue-100 text-blue-800"
      case "medio":
        return "bg-green-100 text-green-800"
      case "universitario":
        return "bg-purple-100 text-purple-800"
      case "avancado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Sugestões de Estudo
          </CardTitle>
          <CardDescription>Carregando sugestões personalizadas...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Sugestões de Estudo
        </CardTitle>
        <CardDescription>Tópicos recomendados por IA baseados no seu perfil</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {suggestions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Nenhuma sugestão disponível no momento.</p>
            <p className="text-sm">Complete alguns estudos para receber recomendações personalizadas.</p>
          </div>
        ) : (
          suggestions.map((suggestion, index) => (
            <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold">{suggestion.title}</h4>
                  <Badge className={getLevelColor(suggestion.level)}>{suggestion.level}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{suggestion.description}</p>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>📚 {suggestion.subject}</span>
                  <span>⏱️ {suggestion.estimatedTime}</span>
                </div>
                {suggestion.reason && (
                  <p className="text-xs text-blue-600 bg-blue-50 p-2 rounded">💡 {suggestion.reason}</p>
                )}
              </div>
              <Button size="sm" onClick={() => router.push("/dashboard/study")}>
                <Play className="h-4 w-4 mr-2" />
                Estudar
              </Button>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
