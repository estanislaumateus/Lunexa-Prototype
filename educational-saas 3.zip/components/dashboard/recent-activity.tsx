"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Clock, CheckCircle, MessageSquare, Trophy } from "lucide-react"

export function RecentActivity() {
  const activities = [
    {
      type: "study",
      title: "Concluiu Matemática Básica",
      time: "2 horas atrás",
      icon: CheckCircle,
      color: "text-green-600",
    },
    {
      type: "chat",
      title: "Conversou com IA sobre Física",
      time: "4 horas atrás",
      icon: MessageSquare,
      color: "text-blue-600",
    },
    {
      type: "assessment",
      title: "Avaliação de História - 9/10",
      time: "1 dia atrás",
      icon: Trophy,
      color: "text-yellow-600",
    },
    {
      type: "study",
      title: "Estudou Inglês por 45 min",
      time: "2 dias atrás",
      icon: Clock,
      color: "text-purple-600",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Atividade Recente</CardTitle>
        <CardDescription>Suas últimas ações na plataforma</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-center space-x-4">
              <Avatar className="h-9 w-9">
                <AvatarFallback>
                  <activity.icon className={`h-4 w-4 ${activity.color}`} />
                </AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <p className="text-sm font-medium leading-none">{activity.title}</p>
                <p className="text-sm text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
