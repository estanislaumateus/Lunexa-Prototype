"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { User, Bell, Palette, Shield, BookOpen } from "lucide-react"

export function SettingsInterface() {
  const { toast } = useToast()
  const [profile, setProfile] = useState({
    name: "João Silva",
    email: "joao@email.com",
    phone: "(11) 99999-9999",
    bio: "Estudante dedicado em busca de conhecimento",
  })

  const [preferences, setPreferences] = useState({
    studyGoal: "2",
    difficulty: "medium",
    subjects: ["mathematics", "history", "physics"],
    language: "pt-BR",
    timezone: "America/Sao_Paulo",
  })

  const [notifications, setNotifications] = useState({
    studyReminders: true,
    assessmentAlerts: true,
    achievements: true,
    weeklyReports: true,
    emailNotifications: false,
    pushNotifications: true,
  })

  const [appearance, setAppearance] = useState({
    theme: "system",
    fontSize: "medium",
    compactMode: false,
    animations: true,
  })

  const handleSaveProfile = () => {
    toast({
      title: "Perfil atualizado",
      description: "Suas informações foram salvas com sucesso.",
    })
  }

  const handleSavePreferences = () => {
    toast({
      title: "Preferências salvas",
      description: "Suas configurações de estudo foram atualizadas.",
    })
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">
            <User className="h-4 w-4 mr-2" />
            Perfil
          </TabsTrigger>
          <TabsTrigger value="study">
            <BookOpen className="h-4 w-4 mr-2" />
            Estudo
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notificações
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Palette className="h-4 w-4 mr-2" />
            Aparência
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-4 w-4 mr-2" />
            Segurança
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>Atualize seus dados pessoais e informações de contato</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome completo</Label>
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile((prev) => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile((prev) => ({ ...prev, email: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={profile.phone}
                  onChange={(e) => setProfile((prev) => ({ ...prev, phone: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Biografia</Label>
                <Input
                  id="bio"
                  value={profile.bio}
                  onChange={(e) => setProfile((prev) => ({ ...prev, bio: e.target.value }))}
                  placeholder="Conte um pouco sobre você..."
                />
              </div>

              <Button onClick={handleSaveProfile}>Salvar Alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="study" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Estudo</CardTitle>
              <CardDescription>Configure suas metas e preferências de aprendizado</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="study-goal">Meta diária (horas)</Label>
                  <Select
                    value={preferences.studyGoal}
                    onValueChange={(value) => setPreferences((prev) => ({ ...prev, studyGoal: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 hora</SelectItem>
                      <SelectItem value="2">2 horas</SelectItem>
                      <SelectItem value="3">3 horas</SelectItem>
                      <SelectItem value="4">4 horas</SelectItem>
                      <SelectItem value="5">5+ horas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="difficulty">Nível de dificuldade</Label>
                  <Select
                    value={preferences.difficulty}
                    onValueChange={(value) => setPreferences((prev) => ({ ...prev, difficulty: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Iniciante</SelectItem>
                      <SelectItem value="medium">Intermediário</SelectItem>
                      <SelectItem value="hard">Avançado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Matérias de interesse</Label>
                <div className="grid gap-2 md:grid-cols-3">
                  {[
                    { id: "mathematics", label: "Matemática" },
                    { id: "history", label: "História" },
                    { id: "physics", label: "Física" },
                    { id: "chemistry", label: "Química" },
                    { id: "biology", label: "Biologia" },
                    { id: "english", label: "Inglês" },
                  ].map((subject) => (
                    <div key={subject.id} className="flex items-center space-x-2">
                      <Switch
                        id={subject.id}
                        checked={preferences.subjects.includes(subject.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setPreferences((prev) => ({
                              ...prev,
                              subjects: [...prev.subjects, subject.id],
                            }))
                          } else {
                            setPreferences((prev) => ({
                              ...prev,
                              subjects: prev.subjects.filter((s) => s !== subject.id),
                            }))
                          }
                        }}
                      />
                      <Label htmlFor={subject.id}>{subject.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <Button onClick={handleSavePreferences}>Salvar Preferências</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Notificação</CardTitle>
              <CardDescription>Escolha como e quando receber notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="study-reminders">Lembretes de estudo</Label>
                    <p className="text-sm text-muted-foreground">Receba lembretes para suas sessões de estudo</p>
                  </div>
                  <Switch
                    id="study-reminders"
                    checked={notifications.studyReminders}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, studyReminders: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="assessment-alerts">Alertas de avaliação</Label>
                    <p className="text-sm text-muted-foreground">Notificações sobre avaliações pendentes</p>
                  </div>
                  <Switch
                    id="assessment-alerts"
                    checked={notifications.assessmentAlerts}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, assessmentAlerts: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="achievements">Conquistas</Label>
                    <p className="text-sm text-muted-foreground">Celebre suas conquistas e marcos</p>
                  </div>
                  <Switch
                    id="achievements"
                    checked={notifications.achievements}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, achievements: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="weekly-reports">Relatórios semanais</Label>
                    <p className="text-sm text-muted-foreground">Resumo semanal do seu progresso</p>
                  </div>
                  <Switch
                    id="weekly-reports"
                    checked={notifications.weeklyReports}
                    onCheckedChange={(checked) => setNotifications((prev) => ({ ...prev, weeklyReports: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications">Notificações por email</Label>
                    <p className="text-sm text-muted-foreground">Receba notificações no seu email</p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={notifications.emailNotifications}
                    onCheckedChange={(checked) =>
                      setNotifications((prev) => ({ ...prev, emailNotifications: checked }))
                    }
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Personalização Visual</CardTitle>
              <CardDescription>Customize a aparência da plataforma</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Tema</Label>
                  <Select
                    value={appearance.theme}
                    onValueChange={(value) => setAppearance((prev) => ({ ...prev, theme: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Claro</SelectItem>
                      <SelectItem value="dark">Escuro</SelectItem>
                      <SelectItem value="system">Sistema</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Tamanho da fonte</Label>
                  <Select
                    value={appearance.fontSize}
                    onValueChange={(value) => setAppearance((prev) => ({ ...prev, fontSize: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Pequena</SelectItem>
                      <SelectItem value="medium">Média</SelectItem>
                      <SelectItem value="large">Grande</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="compact-mode">Modo compacto</Label>
                    <p className="text-sm text-muted-foreground">Interface mais densa com menos espaçamento</p>
                  </div>
                  <Switch
                    id="compact-mode"
                    checked={appearance.compactMode}
                    onCheckedChange={(checked) => setAppearance((prev) => ({ ...prev, compactMode: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="animations">Animações</Label>
                    <p className="text-sm text-muted-foreground">Ativar transições e animações suaves</p>
                  </div>
                  <Switch
                    id="animations"
                    checked={appearance.animations}
                    onCheckedChange={(checked) => setAppearance((prev) => ({ ...prev, animations: checked }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Segurança da Conta</CardTitle>
              <CardDescription>Gerencie a segurança e privacidade da sua conta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current-password">Senha atual</Label>
                  <Input id="current-password" type="password" placeholder="Digite sua senha atual" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-password">Nova senha</Label>
                  <Input id="new-password" type="password" placeholder="Digite sua nova senha" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirmar nova senha</Label>
                  <Input id="confirm-password" type="password" placeholder="Confirme sua nova senha" />
                </div>

                <Button>Alterar Senha</Button>
              </div>

              <div className="pt-6 border-t">
                <h4 className="font-medium mb-4">Zona de Perigo</h4>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full">
                    Exportar Dados
                  </Button>
                  <Button variant="destructive" className="w-full">
                    Excluir Conta
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
