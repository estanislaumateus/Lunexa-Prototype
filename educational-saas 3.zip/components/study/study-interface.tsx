"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Play, BookOpen, Video, FileText } from "lucide-react"

export function StudyInterface() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null)

  const topics = [
    {
      id: "1",
      title: "Álgebra Linear",
      category: "Matemática",
      level: "Universitário",
      description: "Vetores, matrizes e transformações lineares",
      duration: "2h 30min",
    },
    {
      id: "2",
      title: "Revolução Francesa",
      category: "História",
      level: "Médio",
      description: "Causas, desenvolvimento e consequências",
      duration: "1h 45min",
    },
    {
      id: "3",
      title: "Termodinâmica",
      category: "Física",
      level: "Universitário",
      description: "Leis da termodinâmica e aplicações",
      duration: "3h 15min",
    },
  ]

  const filteredTopics = topics.filter(
    (topic) =>
      topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      topic.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar tópicos de estudo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button>
          <BookOpen className="h-4 w-4 mr-2" />
          Novo Tópico
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredTopics.map((topic) => (
          <Card key={topic.id} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Badge variant="secondary">{topic.category}</Badge>
                <Badge variant="outline">{topic.level}</Badge>
              </div>
              <CardTitle className="text-lg">{topic.title}</CardTitle>
              <CardDescription>{topic.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{topic.duration}</span>
                <Button size="sm" onClick={() => setSelectedTopic(topic.id)}>
                  <Play className="h-4 w-4 mr-2" />
                  Estudar
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedTopic && (
        <Card>
          <CardHeader>
            <CardTitle>Conteúdo Gerado por IA</CardTitle>
            <CardDescription>Material personalizado para o tópico selecionado</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="text" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="text">
                  <FileText className="h-4 w-4 mr-2" />
                  Texto
                </TabsTrigger>
                <TabsTrigger value="videos">
                  <Video className="h-4 w-4 mr-2" />
                  Vídeos
                </TabsTrigger>
                <TabsTrigger value="exercises">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Exercícios
                </TabsTrigger>
              </TabsList>

              <TabsContent value="text" className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <h3 className="font-semibold mb-2">Introdução ao Tópico</h3>
                  <p className="text-sm text-muted-foreground">
                    Conteúdo explicativo gerado por IA será exibido aqui...
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="videos" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 border rounded-lg">
                    <div className="aspect-video bg-muted rounded mb-2"></div>
                    <h4 className="font-medium">Vídeo Explicativo 1</h4>
                    <p className="text-sm text-muted-foreground">15 min</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="aspect-video bg-muted rounded mb-2"></div>
                    <h4 className="font-medium">Vídeo Explicativo 2</h4>
                    <p className="text-sm text-muted-foreground">20 min</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="exercises" className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Exercícios Práticos</h4>
                  <p className="text-sm text-muted-foreground">
                    Exercícios gerados automaticamente baseados no conteúdo estudado.
                  </p>
                  <Button className="mt-2" size="sm">
                    Iniciar Exercícios
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
