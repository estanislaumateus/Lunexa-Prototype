# EduSmart - Plataforma Educacional Inteligente

Uma plataforma SaaS educacional moderna desenvolvida com Next.js, oferecendo aprendizado personalizado com inteligência artificial integrada.

## 🚀 Características Principais

### 🎯 Funcionalidades Core
- **Sistema de Autenticação Seguro**: Login/cadastro com validação e criptografia
- **Dashboard Inteligente**: Visão geral do progresso e sugestões personalizadas
- **Área de Estudo**: Conteúdo gerado por IA baseado no perfil do usuário
- **Chat com IA**: Assistente inteligente para tirar dúvidas
- **Sistema de Avaliações**: Testes automáticos com correção inteligente
- **Histórico Detalhado**: Acompanhamento completo do progresso
- **Calendário Interativo**: Visualização e planejamento de estudos
- **Central de Notificações**: Lembretes e alertas personalizados
- **Configurações Avançadas**: Personalização completa da experiência

### 🤖 Integração com IA
- Suporte para múltiplas APIs de IA (ChatGPT, Gemini, Claude)
- Troca automática entre IAs quando limites são atingidos
- Geração de conteúdo educacional personalizado
- Recomendações inteligentes de tópicos de estudo

### 📱 Design Responsivo
- Interface totalmente responsiva para desktop, tablet e mobile
- Sidebar lateral fixa com navegação intuitiva
- Tema claro/escuro com personalização avançada
- Componentes acessíveis seguindo padrões WCAG

## 🛠️ Tecnologias Utilizadas

### Frontend
- **Next.js 14**: Framework React com App Router
- **TypeScript**: Tipagem estática para maior segurança
- **Tailwind CSS**: Framework CSS utilitário
- **shadcn/ui**: Biblioteca de componentes moderna
- **Lucide React**: Ícones consistentes e elegantes

### Backend (Simulado)
- **Next.js API Routes**: Endpoints RESTful
- **Server Actions**: Ações do servidor para formulários
- **JWT**: Autenticação baseada em tokens
- **bcrypt**: Criptografia de senhas

### Banco de Dados (Estrutura)
\`\`\`sql
-- Usuários
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tópicos de Estudo
CREATE TABLE study_topics (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  title VARCHAR(255) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  level ENUM('fundamental', 'medio', 'universitario', 'avancado'),
  progress DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Sessões de Estudo
CREATE TABLE study_sessions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  topic_id INT,
  duration_minutes INT,
  date DATE,
  notes TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (topic_id) REFERENCES study_topics(id)
);

-- Avaliações
CREATE TABLE assessments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  title VARCHAR(255) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  score DECIMAL(4,2),
  total_questions INT,
  correct_answers INT,
  completed_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Chat com IA
CREATE TABLE chat_messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  message TEXT NOT NULL,
  response TEXT,
  ai_provider VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Notificações
CREATE TABLE notifications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('reminder', 'assessment', 'achievement', 'system'),
  read_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
\`\`\`

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+ 
- npm ou yarn

### Instalação
\`\`\`bash
# Clone o repositório
git clone https://github.com/seu-usuario/edusmart-saas.git

# Entre no diretório
cd edusmart-saas

# Instale as dependências
npm install

# Execute em modo de desenvolvimento
npm run dev
\`\`\`

### Variáveis de Ambiente
\`\`\`env
# APIs de IA (opcional para desenvolvimento)
OPENAI_API_KEY=sua_chave_openai
GEMINI_API_KEY=sua_chave_gemini
CLAUDE_API_KEY=sua_chave_claude

# Banco de dados (produção)
DATABASE_URL=sua_string_conexao_mysql

# JWT Secret
JWT_SECRET=seu_jwt_secret_super_seguro

# YouTube API (para vídeos educacionais)
YOUTUBE_API_KEY=sua_chave_youtube
\`\`\`

## 📁 Estrutura do Projeto

\`\`\`
edusmart-saas/
├── app/                          # App Router do Next.js
│   ├── dashboard/               # Páginas do dashboard
│   │   ├── layout.tsx          # Layout com sidebar
│   │   ├── page.tsx            # Dashboard principal
│   │   ├── study/              # Área de estudo
│   │   ├── chat/               # Chat com IA
│   │   ├── history/            # Histórico
│   │   ├── calendar/           # Calendário
│   │   ├── assessments/        # Avaliações
│   │   ├── notifications/      # Notificações
│   │   └── settings/           # Configurações
│   ├── register/               # Página de cadastro
│   ├── layout.tsx              # Layout raiz
│   ├── page.tsx                # Página de login
│   └── globals.css             # Estilos globais
├── components/                  # Componentes React
│   ├── auth/                   # Componentes de autenticação
│   ├── dashboard/              # Componentes do dashboard
│   ├── layout/                 # Layout e navegação
│   ├── study/                  # Interface de estudo
│   ├── chat/                   # Interface de chat
│   ├── history/                # Histórico de estudos
│   ├── calendar/               # Calendário interativo
│   ├── assessments/            # Sistema de avaliações
│   ├── notifications/          # Central de notificações
│   ├── settings/               # Configurações
│   └── ui/                     # Componentes base (shadcn/ui)
├── lib/                        # Utilitários e configurações
├── hooks/                      # Custom hooks
└── types/                      # Definições TypeScript
\`\`\`

## 🔒 Segurança

### Medidas Implementadas
- **Autenticação JWT**: Tokens seguros para sessões
- **Criptografia bcrypt**: Senhas hasheadas com salt
- **Validação de Dados**: Sanitização de inputs
- **Proteção CSRF**: Tokens anti-falsificação
- **Headers de Segurança**: Configurações Next.js
- **Rate Limiting**: Controle de requisições por IP

### Boas Práticas
- Validação tanto no frontend quanto backend
- Sanitização de dados antes do armazenamento
- Logs de segurança para auditoria
- Atualizações regulares de dependências

## 🎨 Personalização

### Temas
- Suporte completo a modo claro/escuro
- Variáveis CSS customizáveis
- Componentes temáticos consistentes

### Responsividade
- Design mobile-first
- Breakpoints otimizados
- Sidebar adaptável para mobile

### Acessibilidade
- Navegação por teclado
- Screen readers compatíveis
- Contraste adequado
- Foco visível

## 🚀 Deploy

### Vercel (Recomendado)
\`\`\`bash
# Instale a CLI da Vercel
npm i -g vercel

# Deploy
vercel --prod
\`\`\`

### Render
1. Conecte seu repositório GitHub
2. Configure as variáveis de ambiente
3. Deploy automático

### Docker
\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
\`\`\`

## 🧪 Testes

\`\`\`bash
# Testes unitários
npm run test

# Testes de integração
npm run test:integration

# Coverage
npm run test:coverage
\`\`\`

## 📈 Roadmap

### Próximas Funcionalidades
- [ ] Integração com APIs de IA reais
- [ ] Sistema de gamificação
- [ ] Relatórios avançados de progresso
- [ ] Integração com Google Calendar
- [ ] App mobile React Native
- [ ] Sistema de mentoria
- [ ] Marketplace de cursos
- [ ] Certificados digitais

### Melhorias Técnicas
- [ ] Testes automatizados completos
- [ ] CI/CD com GitHub Actions
- [ ] Monitoramento com Sentry
- [ ] Analytics com Google Analytics
- [ ] PWA (Progressive Web App)
- [ ] Internacionalização (i18n)

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para detalhes.

## 👥 Equipe

- **Desenvolvedor Principal**: Seu Nome
- **UI/UX Designer**: Nome do Designer
- **DevOps**: Nome do DevOps

## 📞 Suporte

- **Email**: suporte@edusmart.com
- **Discord**: [Servidor da Comunidade](https://discord.gg/edusmart)
- **Documentação**: [docs.edusmart.com](https://docs.edusmart.com)

## 🙏 Agradecimentos

- [Next.js](https://nextjs.org/) pela excelente framework
- [shadcn/ui](https://ui.shadcn.com/) pelos componentes elegantes
- [Tailwind CSS](https://tailwindcss.com/) pelo sistema de design
- [Lucide](https://lucide.dev/) pelos ícones consistentes
- Comunidade open source pelo suporte contínuo

---

**EduSmart** - Transformando a educação com inteligência artificial 🚀
