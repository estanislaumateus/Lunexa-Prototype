import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { anthropic } from "@ai-sdk/anthropic"
import { google } from "@ai-sdk/google"

// Configuração dos provedores de IA
const AI_PROVIDERS = {
  openai: openai("gpt-4o-mini"),
  anthropic: anthropic("claude-3-haiku-20240307"),
  google: google("gemini-1.5-flash"),
}

export type AIProvider = keyof typeof AI_PROVIDERS

// Função para gerar conteúdo educacional
export async function generateEducationalContent(
  topic: string,
  subject: string,
  level: string,
  provider: AIProvider = "openai",
) {
  try {
    const { text } = await generateText({
      model: AI_PROVIDERS[provider],
      system: `Você é um professor especialista em ${subject}. Crie conteúdo educacional claro, didático e adequado para o nível ${level}.`,
      prompt: `Crie um conteúdo educacional completo sobre "${topic}" para estudantes de nível ${level}. 

O conteúdo deve incluir:
1. Introdução ao conceito
2. Explicação detalhada com exemplos
3. Aplicações práticas
4. Exercícios para fixação
5. Dicas de estudo

Mantenha uma linguagem adequada ao nível educacional e seja didático.`,
    })

    return {
      content: text,
      provider,
      success: true,
    }
  } catch (error) {
    console.error(`Erro ao gerar conteúdo com ${provider}:`, error)

    // Tentar com outro provedor
    const fallbackProviders: AIProvider[] = ["openai", "anthropic", "google"]
    const nextProvider = fallbackProviders.find((p) => p !== provider)

    if (nextProvider) {
      return generateEducationalContent(topic, subject, level, nextProvider)
    }

    throw new Error("Todos os provedores de IA falharam")
  }
}

// Função para chat com IA
export async function chatWithAI(message: string, context = "", provider: AIProvider = "openai") {
  try {
    const { text } = await generateText({
      model: AI_PROVIDERS[provider],
      system: `Você é um assistente educacional inteligente. Ajude o estudante com suas dúvidas de forma clara e didática. 
      
Contexto da conversa anterior: ${context}`,
      prompt: message,
    })

    return {
      response: text,
      provider,
      success: true,
    }
  } catch (error) {
    console.error(`Erro no chat com ${provider}:`, error)

    // Tentar com outro provedor
    const fallbackProviders: AIProvider[] = ["openai", "anthropic", "google"]
    const nextProvider = fallbackProviders.find((p) => p !== provider)

    if (nextProvider) {
      return chatWithAI(message, context, nextProvider)
    }

    throw new Error("Todos os provedores de IA falharam")
  }
}

// Função para gerar questões de avaliação
export async function generateAssessmentQuestions(
  subject: string,
  topic: string,
  difficulty: string,
  count = 5,
  provider: AIProvider = "openai",
) {
  try {
    const { text } = await generateText({
      model: AI_PROVIDERS[provider],
      system: `Você é um especialista em criar avaliações educacionais. Crie questões de múltipla escolha bem estruturadas.`,
      prompt: `Crie ${count} questões de múltipla escolha sobre "${topic}" na matéria ${subject}, nível de dificuldade ${difficulty}.

Para cada questão, forneça:
1. A pergunta clara e objetiva
2. 4 alternativas (A, B, C, D)
3. A resposta correta
4. Uma explicação da resposta

Retorne no formato JSON:
{
  "questions": [
    {
      "id": 1,
      "question": "Pergunta aqui",
      "options": ["Opção A", "Opção B", "Opção C", "Opção D"],
      "correct": "Opção correta",
      "explanation": "Explicação da resposta"
    }
  ]
}`,
    })

    const parsed = JSON.parse(text)
    return {
      questions: parsed.questions,
      provider,
      success: true,
    }
  } catch (error) {
    console.error(`Erro ao gerar questões com ${provider}:`, error)

    // Tentar com outro provedor
    const fallbackProviders: AIProvider[] = ["openai", "anthropic", "google"]
    const nextProvider = fallbackProviders.find((p) => p !== provider)

    if (nextProvider) {
      return generateAssessmentQuestions(subject, topic, difficulty, count, nextProvider)
    }

    throw new Error("Todos os provedores de IA falharam")
  }
}

// Função para sugerir tópicos de estudo
export async function suggestStudyTopics(
  userLevel: string,
  preferredSubjects: string[],
  studyHistory: string[],
  provider: AIProvider = "openai",
) {
  try {
    const { text } = await generateText({
      model: AI_PROVIDERS[provider],
      system: `Você é um conselheiro educacional especializado em personalizar planos de estudo.`,
      prompt: `Com base no perfil do estudante, sugira 5 tópicos de estudo personalizados:

Nível do estudante: ${userLevel}
Matérias de interesse: ${preferredSubjects.join(", ")}
Histórico de estudos: ${studyHistory.join(", ")}

Para cada sugestão, forneça:
1. Título do tópico
2. Matéria
3. Nível de dificuldade
4. Breve descrição
5. Tempo estimado de estudo
6. Por que é recomendado para este estudante

Retorne no formato JSON:
{
  "suggestions": [
    {
      "title": "Título do tópico",
      "subject": "Matéria",
      "level": "Nível",
      "description": "Descrição",
      "estimatedTime": "Tempo estimado",
      "reason": "Por que é recomendado"
    }
  ]
}`,
    })

    const parsed = JSON.parse(text)
    return {
      suggestions: parsed.suggestions,
      provider,
      success: true,
    }
  } catch (error) {
    console.error(`Erro ao sugerir tópicos com ${provider}:`, error)

    // Tentar com outro provedor
    const fallbackProviders: AIProvider[] = ["openai", "anthropic", "google"]
    const nextProvider = fallbackProviders.find((p) => p !== provider)

    if (nextProvider) {
      return suggestStudyTopics(userLevel, preferredSubjects, studyHistory, nextProvider)
    }

    throw new Error("Todos os provedores de IA falharam")
  }
}
