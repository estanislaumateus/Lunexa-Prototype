import { LoginForm } from "@/components/auth/login-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">EduSmart</h1>
          <p className="text-gray-600 dark:text-gray-300">Sua plataforma educacional inteligente</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Entrar na Plataforma</CardTitle>
            <CardDescription>Acesse sua conta para continuar seus estudos</CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm />
          </CardContent>
        </Card>

        <div className="text-center text-sm text-gray-600 dark:text-gray-400">
          Não tem uma conta?{" "}
          <a href="/register" className="text-blue-600 hover:underline">
            Cadastre-se gratuitamente
          </a>
        </div>
      </div>
    </div>
  )
}
