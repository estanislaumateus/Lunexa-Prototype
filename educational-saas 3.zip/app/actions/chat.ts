"use server"

import { cookies } from "next/headers"
import { getCurrentUser } from "@/lib/auth"
import { query } from "@/lib/database"
import { chatWithAI } from "@/lib/ai"
import type { ChatMessage } from "@/lib/database"

export async function sendChatMessage(message: string, aiProvider = "openai") {
  const cookieStore = await cookies()
  const token = cookieStore.get("auth-token")?.value
  const user = await getCurrentUser(token)

  if (!user) {
    throw new Error("Usuário não autenticado")
  }

  try {
    // Buscar contexto das últimas mensagens
    const recentMessages = await query(
      `
      SELECT message, response FROM chat_messages
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT 5
    `,
      [user.id],
    )

    const context = (recentMessages as any[])
      .reverse()
      .map((m) => `Usuário: ${m.message}\nIA: ${m.response}`)
      .join("\n\n")

    // Gerar resposta com IA
    const aiResponse = await chatWithAI(message, context, aiProvider as any)

    // Salvar mensagem no banco
    const result = await query(
      `
      INSERT INTO chat_messages (user_id, message, response, ai_provider, context)
      VALUES (?, ?, ?, ?, ?)
    `,
      [user.id, message, aiResponse.response, aiResponse.provider, JSON.stringify({ context })],
    )

    const insertId = (result as any).insertId
    const messages = await query("SELECT * FROM chat_messages WHERE id = ?", [insertId])

    return {
      success: true,
      message: (messages as ChatMessage[])[0],
      aiProvider: aiResponse.provider,
    }
  } catch (error) {
    console.error("Erro no chat:", error)
    return { error: "Erro ao processar mensagem. Tente novamente." }
  }
}

export async function getChatHistory() {
  const cookieStore = await cookies()
  const token = cookieStore.get("auth-token")?.value
  const user = await getCurrentUser(token)

  if (!user) {
    throw new Error("Usuário não autenticado")
  }

  const messages = await query(
    `
    SELECT * FROM chat_messages
    WHERE user_id = ?
    ORDER BY created_at ASC
    LIMIT 50
  `,
    [user.id],
  )

  return messages as ChatMessage[]
}

export async function clearChatHistory() {
  const cookieStore = await cookies()
  const token = cookieStore.get("auth-token")?.value
  const user = await getCurrentUser(token)

  if (!user) {
    throw new Error("Usuário não autenticado")
  }

  await query("DELETE FROM chat_messages WHERE user_id = ?", [user.id])

  return { success: true }
}
