import { AssessmentInterface } from "@/components/assessments/assessment-interface"

export default function AssessmentsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Avaliações</h2>
        <p className="text-muted-foreground">Teste seus conhecimentos e acompanhe seu desempenho</p>
      </div>

      <AssessmentInterface />
    </div>
  )
}
